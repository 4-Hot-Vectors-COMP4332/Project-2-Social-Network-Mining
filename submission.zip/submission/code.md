Please go to the [github page](https://github.com/4-Hot-Vectors-COMP4332/Project-2-Social-Network-Mining) for all codes. 

